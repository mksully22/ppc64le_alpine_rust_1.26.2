void func2(int K) { if (K) {} }
